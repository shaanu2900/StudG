#pyttsx3 is a module we will use for speech
import operator
import random
import smtplib

import numpy as np
import pyautogui
import pyttsx3 # pip install pyttsx3
import datetime

import requests
import speech_recognition as sr # pip install SpeechRecognition
import wikipedia #pip install wikipedia
from smtplib import SMTP
import webbrowser
import os
import cv2
from requests import get
import pywhatkit as kit
import sys
import pyjokes
from PyQt5 import QtWidgets, QtCore, QtGui
from PyQt5.QtCore import QTimer, QTime, QDate, Qt
from PyQt5.QtGui import QMovie
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.uic import loadUiType
from jarvisUi import Ui_JarvisUi

engine = pyttsx3.init()		#Here we intialize the pyttsx3 module to the variable engine

voices = engine.getProperty('voices')		#getProperty('voices') will fetch all the voicess from the module pyttsx3
engine.setProperty('voice', voices[0].id)		#voices[0].id is used to change voice we are having 2 different types of voice 0 is for male and 1 is for female

newVoiceRate = 150
engine.setProperty('rate', newVoiceRate) 		#By default the speed of the speech is 200 words per minute

def speak(audio):
	engine.say(audio)
	print(audio)
	engine.runAndWait()

#speak("Hello Shaantanu how can help you?")

def time():
	Time = datetime.datetime.now().strftime("%I:%M:%S")  	#Here we used the func strftime to convert the time into sting and using the ddatetime.datetime.now we fetch the current systems time
	speak("Current time is")
	speak(Time)

#time()

def date():
	year = int(datetime.datetime.now().year)
	month = int(datetime.datetime.now().month)
	date = int(datetime.datetime.now().day)
	speak("Todays date is")
	speak(date)
	speak(month)
	speak(year)

# date()

def wishme():
	speak("Welcome back Sir!")
	hour = datetime.datetime.now().hour

	if hour >= 6 and hour < 12:
		speak("Good Morning")
	elif hour >= 12 and hour < 18:
		speak("Good afternoon")
	elif hour >= 18 and hour < 21:
		speak("Good Evening")
	else:
		speak("Good Night")

	speak("STUD G at your service , How can i help you?")

# wishme()

def sendemail(to,content):
	server = smtplib.SMTP('smtp.gmail.com', 587) #587 is the port number to send email
	server.ehlo()
	server.starttls() #It is a predefined function to send email
	server.login("kadamshaantanu29@gmail.com", "0000000000000")
	server.sendemail("kadamshaantanu29@gmail.com", to, content)
	server.close()

def news():
	main_url = 'http://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=02edd382050b4f54a3431be375bbace8'
	main_page = requests.get(main_url).json()
	# print(main_page)
	articles = main_page["articles"]
	#print(articles)
	head = []
	day=["first","second","third","fourth","fifth"]
	for ar in articles:
		head.append(ar["title"])
	for i in range (len(day)):
		#print(f"today's {day[i]} news is: ", head[i])
		speak(f"today's {day[i]} news is:, {head[i]}")

class MainThread(QThread):
	def __init__(self):
		super(MainThread,self).__init__()

	def run(self):
		self.TaskExecution()

	def takecommand(self):
		r = sr.Recognizer()  # Here we intialize our 'r' to the speech recognizer
		with sr.Microphone() as source:  # We are usinig microphones as our source of input
			print("Listening...")
			r.pause_threshold = 1  # It will wait for 1 second before listening
			audio = r.listen(source, timeout=1, phrase_time_limit=5)

		try:
			print("Recognizing...")
			self.query = r.recognize_google(audio, language='en=in')
			print(self.query)

		except Exception as e:  # If there is an error we will use the except block
			print(e)
			speak("Say that again please")

			return "None"

		return self.query

	# takecommand()

	def TaskExecution(self):

		wishme()

		while True:

			self.query = self.takecommand().lower()
			if "date" in self.query:
				date()
			elif "time" in self.query:
				time()
			elif "offline" in self.query:
				quit()
			elif "goodbye" in self.query:
				quit()
			elif "dead" in self.query:
				quit()
			elif "send email" in self.query:
				try:
					to ="kadamshaantanu29@gmail.com"
					speak("What should I say?")
					content = self.takecommand()
					sendemail(to,content)
					speak(content)
				except Exception as e:
					print(e)
					speak("Unable to send email")

			elif "open notepad" in self.query:
				npath = "C:\\Windows\\notepad.exe"
				os.startfile(npath)

			elif "close notepad" in self.query:
				speak("As you wish sir, Closing Notepad")
				os.system("taskkill/f /im notepad.exe")

	#Open Command promt
			elif "open command prompt" in self.query:
				os.system("start cmd")
			elif "open cmd" in self.query:
				os.system("start cmd")

	#To open Camera we needed to install pip install opencv-python
			elif "open camera" in self.query:
				cap = cv2.VideoCapture(0)
				while True:
					ret, img = cap.read()
					cv2.imshow('webcam',img)
					k = cv2.waitKey(50)
					if k==27:
						break;
				cap.release()
				cv2.destroyAllWindows()

			elif "play music" in self.query:
				music_dir = "C:\\Users\\Dell\\Music\\Music 17"
				songs = os.listdir(music_dir)
				rd = random.choice(songs)
				os.startfile(os.path.join(music_dir, rd))

			elif "ip address" in self.query:
				ip = get('https://api.ipify.org').text
				speak(f"your IP address is {ip}")

			elif "wikipedia" in self.query:
				speak("searching wikipedia....")
				self.query = self.query.replace("wikipedia", "")
				results = wikipedia.summary(self.query, sentences=2)
				speak("according to wikipedia")
				speak(results)
				print(results)

			elif "open Youtube" in self.query:
				webbrowser.open("www.youtube.com")

			elif "open Google" in self.query:
				speak("sir, what should I search on Google?")
				cm = self.takecommand().lower()
				webbrowser.open(f"{cm}")

			elif "send message" in self.query:
				kit.sendwhatmsg("+918511428999", "this is testing protocol",18,14)

			elif "play songs on youtube" in self.query:
				kit.playonyt("heeriye")

			elif "no thanks" in self.query:
				speak("Thank you for your time sir! Take care and Have a Great Day ahead")
				sys.exit()
			elif "no thank you" in self.query:
				speak("Thank you for your time sir! Take care and Have a Great Day ahead")
				sys.exit()

			elif "set alarm" in self.query:
				nn = int(datetime.datetime.now().hour)
				if nn==22:
					music_dir = 'C:\\Users\\mauli\\Music\\Music 1'
					songs = os.listdir(music_dir)
					os.startfile((os.path.join(music_dir, songs[0])))

			elif "tell me a joke" in self.query:
				joke = pyjokes.get_joke()
				speak(joke)

			elif "tell me another joke" in self.query:
				joke = pyjokes.get_joke()
				speak(joke)

			elif "tell me a joke again" in self.query:
				joke = pyjokes.get_joke()
				speak(joke)

			elif "shut down the system" in self.query:
				os.system("shutdown /s /t 5")

			elif "restart the system" in self.query:
				os.system("shutdown /r /t 5")

			elif "sleep the system" in self.query:
				os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")

			elif "where am I" in self.query or "where are we" in self.query:
				speak("wait sir, let me check")
				try:
					ipAdd = requests.get('https://api.ipify.org').text
					print(ipAdd)
					url = 'https://geojs.io/v1/ip/geo/'+ipAdd+'.json'
					geo_requests = requests.get(url)
					geo_data = geo_requests.json()
					#print(geo_data)
					city = geo_data['city']
					#state - geo_data['state']
					country = geo_data['country']
					speak(f"sir I am not sure, but i think we are in {city} city of {country}")
				except Exception as e:
					speak("sorry sir, due to network issue i am not able to find where we are.")

			elif "take screenshot" in self.query or "take a screenshot" in self.query:
				speak("sir, please tell me the name for this screenshot file")
				name = self.takecommand().lower()
				speak("please sir hold the screen for few seconds, I am taking screenshot")
				#time.sleep(3)
				img = pyautogui.screenshot()
				img.save(f"{name}.png")
				speak("I am done sir, the screenshot is successfully saved in our main folder.")

			elif 'switch the window' in self.query:
				pyautogui.keyDown("alt")
				pyautogui.press("tab")
				time()
				pyautogui.keyUp("alt")

			elif "tell me the latest news" in self.query:
				speak("Please give me a movement while fetching the latest news")
				news()

			elif "do some calculations" in self.query or "can you calculate" in self.query:
				r = sr.Recognizer()
				with sr.Microphone() as source:
					speak("Say what do you want to calculate, example: 3 plus 3")
					print("listning......")
					r.adjust_for_ambient_noise(source)
					audio = r.listen(source)
				my_string=r.recognize_google(audio)
				print(my_string)
				def get_operator_fn(op):
					return {
						'+' : operator.add, #plus
						'-' : operator.sub, #subtraction
						'*' : operator.mul, #multiplication
						'divided': operator.__truediv__, #divison
	 					}[op]
				def eval_binary_expr(op1, oper, op2):
					op1,op2 = int(op1), int(op2)
					return get_operator_fn(oper)(op1,op2)
				speak("your result is ")
				speak(eval_binary_expr(*(my_string.split())))

			elif 'volume up' in self.query:
				pyautogui.press("volumeup")


			elif 'volume down' in self.query:
				pyautogui.press("volumedown")

			elif 'volume mute' in self.query or 'mute' in self.query:
				pyautogui.press("volumemute")

			elif "open my mobile camera" in self.query:
				import urllib.request
				import cv2 #pip install opencv-python
				import numpy as np #pip install numpy
				import time
				URl = "http://192.168.113.127:8080/shot.jpg"
				while True:
					img_arr = np.array(bytearray(urllib.request.urlopen(URl).read()),dtype=np.uint8)
					img = cv2.imdecode(img_arr,-1)
					cv2.imshow('IPWebcam',img)
					q = cv2.waitKey(1)
					if q == ord("q"):
						break;

				cv2.destroyAllWindows()


			speak("Task Completed, Do you want any other help?")

startExecution = MainThread()

class Main(QMainWindow):
	def __init__(self):
		super().__init__()
		self.ui = Ui_JarvisUi()
		self.ui.setupUi(self)
		self.ui.pushButton.clicked.connect(self.startTask)
		self.ui.pushButton_2.clicked.connect(self.close)

	def startTask(self):
		self.ui.movie = QtGui.QMovie("C:/Users/Dell/Downloads/7LP8 (1).gif")
		self.ui.label.setMovie(self.ui.movie)
		self.ui.movie.start()
		self.ui.movie = QtGui.QMovie("C:/Users/Dell/Downloads/T8bahf (1).gif")
		self.ui.label_2.setMovie(self.ui.movie)
		self.ui.movie.start()
		timer = QTimer(self)
		timer.timeout.connect(self.showTime)
		timer.start(3000)
		startExecution.start()

	def showTime(self):
		current_time = QTime.currentTime()
		current_date = QDate.currentDate()
		label_time = current_time.toString('hh:mm:ss')
		label_date = current_date.toString(Qt.ISODate)
		self.ui.textBrowser.setText(label_date)
		self.ui.textBrowser_2.setText(label_time)


app = QApplication(sys.argv)
jarvis = Main()
jarvis.show()
exit(app.exec_())

